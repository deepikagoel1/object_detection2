
proto-avengers - v1 2021-06-07 3:54pm
==============================

This dataset was exported via roboflow.ai on June 7, 2021 at 10:26 AM GMT

It includes 199 images.
Labels are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


